#include<iostream>
#include<iomanip>

using namespace std;

struct user{
	int userid;
	string username;
	int quiz[3];
};

struct users{
	user u[5];
	
};

user input();
users display(users us1);
int again();
int fail(int temp);

int ctr0 = 1;

int main(){

	users us;
	LOOP4:
	int ctr1 = 0;
	int ctr2 = 0;
	
	while (ctr1 < 5){	
		us.u[ctr1] = input();
		ctr1++;
	}	
	us = display(us);
	ctr2 = again();
	
	if(ctr2 == 1){
		goto LOOP4;
	}else{
		return 0;
	}
	
}

user input(){
	
	user temp1;
	int ctr = 0;
	
	LOOP1:
	
	cout	<< "***Enter User Info " << ctr0 << " :***\n";
	cout	<< "Enter Id: ";
	cin		>> temp1.userid;
	
	if(cin.fail()){
		fail(0);
		goto LOOP1;
	}
	
	cout	<< "Enter Name: ";
	cin		>> temp1.username;
	
	
	if(cin.fail()){
		fail(1);
		goto LOOP1;
	}
	
	LOOP2:
	
	while (ctr < 3){
		
		cout	<< "Enter Quiz " << ctr + 1 << ": ";
		cin		>> temp1.quiz[ctr];
		
		if(cin.fail()){
			ctr = 0;
			fail(0);
			goto LOOP2;
		}
		
		if(temp1.quiz[ctr] < 0){
			cout	<< "\nPlease input positive integers!\n\n";
			ctr = 0;
			goto LOOP2;
		}
		
		ctr++;
	}
	
	ctr0++;
	return temp1;
	
}


users display(users us){
	
	int ctr = 0;
	
		
	cout	<< "\n\n"
			<< "Student Record\n"
			<< setw(5)
			<<	"No. "
			<< setw(10)
			<< "ID: "
			<< setw(40)
			<< "Name: "
			<< setw(12)
			<< "Quiz 1: "
			<< setw(12)
			<< "Quiz 2: "
			<< setw(12)
			<< "Quiz 3: \n";
			
			
	while(ctr < 5){
		cout	<< setw(5)
				<< ctr+1
				<< setw(10)
				<< us.u[ctr].userid
				<< setw(40)
				<< us.u[ctr].username
				<< setw(12)
				<< us.u[ctr].quiz[0]
				<< setw(12)
				<< us.u[ctr].quiz[1]
				<< setw(12)
				<< us.u[ctr].quiz[2] 
				<< "\n";
	ctr++;
	}
	
	return us;
	
}

int again(){
	
	string choice = "";
	ctr0 = 1;
	LOOP3:
	
	cout	<< "\n\n"
			<< "Try Again?\n"
			<< "y/n: ";
	cin		>> choice;
	
	if(choice == "y" || choice == "Y"){
		cout	<< "\n";
		return 1;
	}else if (choice == "n" || choice == "N"){
		cout	<< "\n";
		return 0;
	}else{
			cout	<< "\n\n"
					<< "Please Input within specified Choices: \n";
			goto LOOP3;
	}
}


int fail(int temp){
        cin.clear(); 
		cin.ignore(100,'\n');
		if(temp == 1){
			cout	<< "\nPlease input proper letters!\n";
		}else{
			cout	<< "\nPlease input real numbers!\n";
		}
		
}
