#include<iostream>
using namespace std;
int area(int);
int area(int,int);
float area(float);
float area(float,float);
int main()
{a:


	int s,l,w,A;
	float r,bs,ht;

	cout<< "[1] Area of Square\n";
	cout<< "[2] Area of Rectangle\n";
	cout<< "[3] Area of Triangle\n";
	cout<< "[4] Area of Circle\n";
	cout<< "[5] Exit\n";
	cout<<"----------------------------------\n";
	cout<< "Enter Number:\n";
	cin>>A;

	if(A==1)
	{	
	cout<<"Enter side of a square:";
	cin>>s;		
	cout<<"Area of square is"<<area(s);
}
	if(A==2)
	{
	cout<<"Enter length and width of the rectangle:";
	cin>>l>>w;	
	cout<<"\nArea of rectangle is "<<area(l,w);
}
	if(A==3)
	{
	cout<<"Enter base and height of triangle:";
	cin>>bs>>ht;
    cout<<"\nArea of triangle is "<<area(bs,ht);
}
	if(A==4)
{
	cout<<"Enter radius of circle:";
	cin>>r;
	cout<<"\nArea of circle is "<<area(r);
}

	if (A==5)
	{
		cout<< "Thank you, Have a Good Day!\n";
	
		return 0;
	}
		goto a;
}
	int s,l,w;
	float r,bs,ht;



int area(int s)
{
    return(s*s);
}
int area(int l,int w)
{
    return(l*w);
}
float area(float r)
{
    return(3.14*r*r);
}
float area(float bs,float ht)
{
   return((bs*ht)/2);
   
}

