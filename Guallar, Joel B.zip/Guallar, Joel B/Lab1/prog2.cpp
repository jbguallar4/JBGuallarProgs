#include<iostream>
#include<stdlib.h>
#include"checker.h"
using namespace std;

int main()

{
Start:{
	
int a[10], n, i;
char again;
system("cls");
cout<<"Enter a number:"; cin>>n;
for(i=0; n>0; i++)
{a[i] = n%2;
n = n/2;
}
cout<<"Binary:";
for(i=i-1; i>=0; i--)
{
	cout<<a[i];
	
}

Initiate:{printf("\nDo you want to try again?[Y/N]:");
scanf("%s", &again);
fflush(stdin);

if(again=='Y'||again=='y'){
	goto Start;

}

if(again=='N'||again=='n'){
	printf("Thank You and Have A Good Day!!!");
	return 0;
}
else{
	printf("Invalid Input\n");
	goto Initiate;
}
}
}
}
